-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema retailshop
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema retailshop
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `retailshop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `retailshop` ;

-- -----------------------------------------------------
-- Table `retailshop`.`vendor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`vendor` (
  `vendorid` VARCHAR(255) NOT NULL,
  `active` BIT(1) NOT NULL,
  `address` VARCHAR(255) NULL DEFAULT NULL,
  `email` VARCHAR(255) NULL DEFAULT NULL,
  `name` VARCHAR(255) NULL DEFAULT NULL,
  `phone` VARCHAR(255) NULL DEFAULT NULL,
  `pwd` VARCHAR(255) NULL DEFAULT NULL,
  `role` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`vendorid`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `retailshop`.`category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`category` (
  `catid` INT NOT NULL AUTO_INCREMENT,
  `catname` VARCHAR(50) NULL DEFAULT NULL,
  `vendorid` VARCHAR(255) NULL DEFAULT NULL,
  `vendor_vendorid` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`catid`),
  INDEX `FK9i1iiq7y6cxubxw04wd24lkse` (`vendor_vendorid` ASC) VISIBLE,
  CONSTRAINT `FK9i1iiq7y6cxubxw04wd24lkse`
    FOREIGN KEY (`vendor_vendorid`)
    REFERENCES `retailshop`.`vendor` (`vendorid`))
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `retailshop`.`product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`product` (
  `prodid` INT NOT NULL AUTO_INCREMENT,
  `catid` INT NOT NULL,
  `company` VARCHAR(255) NULL DEFAULT NULL,
  `deleted` BIT(1) NOT NULL,
  `pic` VARCHAR(255) NULL DEFAULT NULL,
  `pname` VARCHAR(255) NULL DEFAULT NULL,
  `saleprice` FLOAT NOT NULL,
  `vendorid` VARCHAR(255) NULL DEFAULT NULL,
  `category_catid` INT NULL DEFAULT NULL,
  `vendor_vendorid` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`prodid`),
  INDEX `FKm06c9i95wxavx4oyvfksuweuy` (`category_catid` ASC) VISIBLE,
  INDEX `FKdcniaaw1upya1i77sd3n23s4s` (`vendor_vendorid` ASC) VISIBLE,
  INDEX `FKo4pdyc4iw04fvvyhk47fkfy06` (`vendorid` ASC) VISIBLE,
  INDEX `FKq6hhjex8p6noh29xumcr247oc` (`catid` ASC) VISIBLE,
  CONSTRAINT `FKdcniaaw1upya1i77sd3n23s4s`
    FOREIGN KEY (`vendor_vendorid`)
    REFERENCES `retailshop`.`vendor` (`vendorid`),
  CONSTRAINT `FKm06c9i95wxavx4oyvfksuweuy`
    FOREIGN KEY (`category_catid`)
    REFERENCES `retailshop`.`category` (`catid`),
  CONSTRAINT `FKo4pdyc4iw04fvvyhk47fkfy06`
    FOREIGN KEY (`vendorid`)
    REFERENCES `retailshop`.`vendor` (`vendorid`),
  CONSTRAINT `FKq6hhjex8p6noh29xumcr247oc`
    FOREIGN KEY (`catid`)
    REFERENCES `retailshop`.`category` (`catid`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `retailshop`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`customer` (
  `userid` VARCHAR(255) NOT NULL,
  `city` VARCHAR(255) NULL DEFAULT NULL,
  `cpwd` VARCHAR(255) NULL DEFAULT NULL,
  `dob` VARCHAR(255) NULL DEFAULT NULL,
  `email` VARCHAR(255) NOT NULL,
  `fname` VARCHAR(255) NULL DEFAULT NULL,
  `gender` VARCHAR(255) NULL DEFAULT NULL,
  `lname` VARCHAR(255) NULL DEFAULT NULL,
  `pwd` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE INDEX `UK_dwk6cx0afu8bs9o4t536v1j5v` (`email` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `retailshop`.`cart`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`cart` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `prodid` INT NOT NULL,
  `qty` INT NOT NULL,
  `userid` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKgsr46n9fx6u1mxboqo4umsmed` (`userid` ASC) VISIBLE,
  INDEX `FKfh2bssxmgq9jblm2x79ftpo9a` (`prodid` ASC) VISIBLE,
  CONSTRAINT `FKfh2bssxmgq9jblm2x79ftpo9a`
    FOREIGN KEY (`prodid`)
    REFERENCES `retailshop`.`product` (`prodid`),
  CONSTRAINT `FKgsr46n9fx6u1mxboqo4umsmed`
    FOREIGN KEY (`userid`)
    REFERENCES `retailshop`.`customer` (`userid`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `retailshop`.`orders`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `cardno` VARCHAR(255) NULL DEFAULT NULL,
  `nameoncard` VARCHAR(255) NULL DEFAULT NULL,
  `orderdate` DATETIME NULL DEFAULT NULL,
  `status` VARCHAR(255) NULL DEFAULT NULL,
  `userid` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKs0wfkc68ijed8l5m27hiq41n9` (`userid` ASC) VISIBLE,
  CONSTRAINT `FKs0wfkc68ijed8l5m27hiq41n9`
    FOREIGN KEY (`userid`)
    REFERENCES `retailshop`.`customer` (`userid`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `retailshop`.`order_details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `retailshop`.`order_details` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `orderid` INT NOT NULL,
  `price` FLOAT NOT NULL,
  `prodid` INT NOT NULL,
  `qty` INT NOT NULL,
  `status` VARCHAR(255) NULL DEFAULT NULL,
  `vendorid` VARCHAR(255) NULL DEFAULT NULL,
  `order_id` INT NULL DEFAULT NULL,
  `product_prodid` INT NULL DEFAULT NULL,
  `vendor_vendorid` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKjyu2qbqt8gnvno9oe9j2s2ldk` (`order_id` ASC) VISIBLE,
  INDEX `FKj848vcctj34t2g7j81t97q06v` (`product_prodid` ASC) VISIBLE,
  INDEX `FKhxsnfogo3jlcbpg1bdx872jy3` (`vendor_vendorid` ASC) VISIBLE,
  INDEX `FKh35b1ljeu4440iie9psw8a7yt` (`orderid` ASC) VISIBLE,
  CONSTRAINT `FKh35b1ljeu4440iie9psw8a7yt`
    FOREIGN KEY (`orderid`)
    REFERENCES `retailshop`.`orders` (`id`),
  CONSTRAINT `FKhxsnfogo3jlcbpg1bdx872jy3`
    FOREIGN KEY (`vendor_vendorid`)
    REFERENCES `retailshop`.`vendor` (`vendorid`),
  CONSTRAINT `FKj848vcctj34t2g7j81t97q06v`
    FOREIGN KEY (`product_prodid`)
    REFERENCES `retailshop`.`product` (`prodid`),
  CONSTRAINT `FKjyu2qbqt8gnvno9oe9j2s2ldk`
    FOREIGN KEY (`order_id`)
    REFERENCES `retailshop`.`orders` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;