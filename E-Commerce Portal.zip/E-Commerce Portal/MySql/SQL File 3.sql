INSERT INTO `category` (`catid`, `catname`, `vendorid`, `vendor_vendorid`) VALUES
(1, 'Washing Machines', 'admin', 'admin'),
(2, 'Televisions', 'admin', 'admin'),
(3, 'Mobiles', 'admin', 'admin'),
(4, 'Shirts', 'admin', 'admin'),
(5, 'Laptops', 'admin', 'admin'),
(6, 'Jeans', 'admin', 'admin');

INSERT INTO `product` (`prodid`, `catid`, `company`, `deleted`, `pic`, `pname`, `saleprice`, `vendorid`, `category_catid`, `vendor_vendorid`) VALUES
(1, 4, 'Raymonds', b'0', '/pics/shirt2.jpg', 'Pink Shirt', 500, 'admin', 4, 'admin'),
(2, 4, 'Raymonds', b'0', '/pics/shirt.jpg', 'Blue Shirts', 800, 'admin', 4, 'admin'),
(3, 5, 'Samsung', b'0', '/pics/253-0152_PI_1000560MN.jpg', 'Samsung XYZ1', 25000, 'admin', 5, 'admin'),
(4, 5, 'HCL', b'0', '/pics/images.jpg', 'HCL 1234', 35000, 'admin', 5, 'admin');